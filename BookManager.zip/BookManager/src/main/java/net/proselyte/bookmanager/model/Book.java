package net.proselyte.bookmanager.model;

import javax.persistence.*;
import java.text.SimpleDateFormat;

@Entity
@Table(name = "BOOKS")
public class Book {
    @Id
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column(name = "NAME")
    private String bookTitle;

//    @Column(name = "BOOK_AUTHOR")
//    private String bookAuthor;

    @Column(name = "AGE")
    private int price;

//    @Column(name = "ISADMIN")
//    private boolean isAdmin;
//
//    @Column(name = "CREATEDATE")
//    private String createDate;


//    public void setIsAdmin(boolean isAdmin) {
//        this.isAdmin = isAdmin;
//    }
//
//    public void setCreateDate(String createDate) {
//
//        this.createDate = createDate;
//    }
//
//    public String getCreateDate() {
//        return createDate;
//    }
//
//    public boolean getIsAdmin() {
//
//        return isAdmin;
//    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getBookTitle() {
        return bookTitle;
    }

    public void setBookTitle(String bookTitle) {
        this.bookTitle = bookTitle;
    }

//    public String getBookAuthor() {
//        return bookAuthor;
//    }
//
//    public void setBookAuthor(String bookAuthor) {
//        this.bookAuthor = bookAuthor;
//    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    @Override
    public String toString() {
        return "Book{" +
                "id=" + id +
                ", bookTitle='" + bookTitle + '\'' +
                ", price=" + price +
                '}';
    }
}
