package net.proselyte.bookmanager.controller;

import com.sun.deploy.net.HttpResponse;
import net.proselyte.bookmanager.model.Book;
import net.proselyte.bookmanager.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpServletRequest;

@Controller
public class BookController {
    private BookService bookService;
    private Long page = Long.valueOf(0);

    @Autowired(required = true)
    @Qualifier(value = "bookService")
    public void setBookService(BookService bookService) {
        this.bookService = bookService;
    }

    @RequestMapping(value = "books", method = RequestMethod.GET)
    public String listBooks(@RequestParam(value = "page", required = false, defaultValue = "0") Long page, Model model) {

        this.page = page;
        if ( page.intValue() >0 ) {
            model.addAttribute("prev", true);
        } else {
            model.addAttribute("prev", false);
        }


        if ( page !=0 && this.bookService.countElement()/page < page.intValue() ) {
            model.addAttribute("next", false);
        } else {
            model.addAttribute("next", true);
        }

        System.out.println("/GGGGGGGGGGGGGGGGGGGG");
        System.out.println("this.page " + this.page);
        System.out.println("count element " + this.bookService.countElement());

        model.addAttribute("page", this.page);
        model.addAttribute("book", new Book());
        model.addAttribute("listBooks", this.bookService.listBooks(this.page));

        return "books";
    }

    @RequestMapping(value = "/books/add", method = RequestMethod.POST)
    public String addBook(@ModelAttribute("book") Book book) {
        if (book.getId() == 0) {
            this.bookService.addBook(book);
        } else {
            this.bookService.updateBook(book);
        }

        return "redirect:/books";
    }

    @RequestMapping("/remove/{id}")
    public String removeBook(@PathVariable("id") int id) {
        this.bookService.removeBook(id);

        return "redirect:/books";
    }

    @RequestMapping("edit/{id}")
    public String editBook(@PathVariable("id") int id, Model model) {
        model.addAttribute("book", this.bookService.getBookById(id));
        model.addAttribute("listBooks", this.bookService.listBooks(this.page));

        model.addAttribute("test", "test");

        return "books";
    }

    @RequestMapping("bookdata/{id}")
    public String bookData(@PathVariable("id") int id, Model model) {
        model.addAttribute("book", this.bookService.getBookById(id));

        return "bookdata";
    }


    @RequestMapping(value = "/books/serch", method = RequestMethod.POST)
    public String searchlistBooks(@RequestParam("j_username") String username, HttpServletRequest reques, Model model, RedirectAttributes redirectAttributes) {
        redirectAttributes.addFlashAttribute("searchlistBooks", this.bookService.searchBooks(username));


        return "redirect:/books";
    }


}
